## References

+ Background picture
    + [Pokemon, HD Cartoons, 4k Wallpapers, Images, Backgrounds, Photos and Pictures](https://hdqwalls.com/pokemon-wallpaper)
+ Pokemon Ball Picture
    + [File:Pokeball.PNG - Wikipedia](https://en.wikipedia.org/wiki/File:Pokeball.PNG)
+ Pokemon Icons
    + [Pokédex \| Pokemon.com](https://www.pokemon.com/us/pokedex/)

